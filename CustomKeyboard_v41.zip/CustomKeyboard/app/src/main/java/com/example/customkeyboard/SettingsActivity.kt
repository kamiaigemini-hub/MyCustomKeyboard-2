package com.example.customkeyboard

import android.app.AlertDialog
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.customkeyboard.model.KeyDef
import com.example.customkeyboard.model.KeyType
import com.example.customkeyboard.model.KeyboardLayout
import com.example.customkeyboard.model.LanguageStore
import com.example.customkeyboard.model.LayoutStore
import com.example.customkeyboard.model.SymbolPageStore
import com.example.customkeyboard.model.ThemeStore
import com.example.customkeyboard.view.KeyboardView

class SettingsActivity : AppCompatActivity() {

    // 조합 키(성조/발음기호 등)를 만들 때 고를 수 있는 프리셋. 유니코드를 몰라도 탭 한 번으로 고를 수 있어요.
    private val markPresets = listOf(
        "´ 억양(acute)" to "\u0301",
        "` 그레이브(grave)" to "\u0300",
        "~ 물결(tilde)" to "\u0303",
        "^ 모자(circumflex)" to "\u0302",
        "˘ 브레베(breve)" to "\u0306",
        ". 밑점(dot below)" to "\u0323",
        "̉ 고리(hook above)" to "\u0309",
        "¨ 움라우트(umlaut)" to "\u0308",
        "˚ 고리위(ring above)" to "\u030A",
        ", 세디유(cedilla)" to "\u0327",
        "ˇ 캐런(caron)" to "\u030C",
        "+ 뿔(horn)" to "\u031B",
        "d→đ (스트로크)" to "STROKE"
    )

    // 이름을 "layout"으로 하면 Button 같은 View들이 원래 갖고 있는 layout(getLayout())과 이름이 겹쳐서
    // 컴파일러가 헷갈릴 수 있어 "editLayout"이라는 이름을 씁니다.
    private lateinit var editLayout: KeyboardLayout
    private lateinit var keyboardView: KeyboardView
    private lateinit var langTabsContainer: LinearLayout
    private lateinit var rowPickerContainer: LinearLayout
    private lateinit var deletePageBtn: Button
    private var currentCode: String = "ko"
    private var selectedRowForOps: Int = 0
    private var moveSourceKey: KeyDef? = null
    private var pendingExportJson: String? = null

    private val exportFileLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val json = pendingExportJson
        pendingExportJson = null
        if (uri != null && json != null) {
            try {
                contentResolver.openOutputStream(uri)?.use { out -> out.write(json.toByteArray()) }
                Toast.makeText(this, "저장했어요!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "저장에 실패했어요", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val importFileLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                if (text != null) {
                    editLayout = LayoutStore.importJson(text)
                    selectedRowForOps = 0
                    moveSourceKey = null
                    keyboardView.highlightedKey = null
                    renderRowPicker()
                    renderPreview()
                    persist()
                    Toast.makeText(this, "가져왔어요!", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "파일을 확인해주세요 (제대로 내보낸 파일이 맞는지)", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val installed = LanguageStore.installedLanguages(this)
        currentCode = intent.getStringExtra(EXTRA_LANG_CODE) ?: installed.firstOrNull()?.code ?: "en"
        editLayout = LayoutStore.loadLayout(this, currentCode)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val langTabsScroll = HorizontalScrollView(this)
        langTabsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(16, 24, 16, 8)
        }
        langTabsScroll.addView(langTabsContainer)
        root.addView(langTabsScroll)

        deletePageBtn = Button(this).apply {
            text = "이 페이지 삭제"
            visibility = android.view.View.GONE
            setOnClickListener {
                if (currentCode.startsWith("emoji_custom_")) {
                    EmojiPageStore.removePage(this@SettingsActivity, currentCode)
                    switchTab("emoji_smileys")
                } else {
                    SymbolPageStore.removePage(this@SettingsActivity, currentCode)
                    switchTab("symbols")
                }
            }
        }
        root.addView(deletePageBtn)

        val info = TextView(this).apply {
            text = "아래 미리보기에서 키를 탭하면 편집돼요. 길게 누르면 이동 모드가 되고, " +
                "옮길 위치의 키에서 왼쪽을 탭하면 그 키 앞으로, 오른쪽을 탭하면 그 키 뒤로 이동해요.\n" +
                "행 전체를 옮기고 싶으면 아래 '행 선택'에서 고른 다음 ▲▼ 버튼을 쓰세요."
            setPadding(32, 8, 32, 16)
        }
        root.addView(info)

        keyboardView = KeyboardView(this).apply {
            onKeyListener = { key -> onPreviewKeyTapped(key) }
            onKeyLongPressListener = { key ->
                moveSourceKey = key
                highlightedKey = key
            }
            onKeyTapDetail = { key, tapX, rect ->
                val source = moveSourceKey
                if (source != null && source !== key) {
                    val insertBefore = tapX < rect.centerX()
                    performMoveWithSide(source, key, insertBefore)
                    moveSourceKey = null
                    highlightedKey = null
                }
            }
            applyTheme(ThemeStore.load(this@SettingsActivity))
        }
        root.addView(keyboardView)

        val rowPickerLabel = TextView(this).apply {
            text = "행 선택 (아래 버튼들이 적용될 행):"
            setPadding(32, 24, 32, 4)
        }
        root.addView(rowPickerLabel)

        val rowPickerScroll = HorizontalScrollView(this)
        rowPickerContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(16, 0, 16, 8)
        }
        rowPickerScroll.addView(rowPickerContainer)
        root.addView(rowPickerScroll)

        val rowMoveBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        rowMoveBar.addView(Button(this).apply {
            text = "▲ 선택한 행 위로"
            setOnClickListener {
                if (selectedRowForOps > 0) {
                    val tmp = editLayout.rows[selectedRowForOps]
                    editLayout.rows[selectedRowForOps] = editLayout.rows[selectedRowForOps - 1]
                    editLayout.rows[selectedRowForOps - 1] = tmp
                    selectedRowForOps -= 1
                    renderRowPicker()
                    renderPreview()
                    persist()
                }
            }
        })
        rowMoveBar.addView(Button(this).apply {
            text = "▼ 선택한 행 아래로"
            setOnClickListener {
                if (selectedRowForOps < editLayout.rows.size - 1) {
                    val tmp = editLayout.rows[selectedRowForOps]
                    editLayout.rows[selectedRowForOps] = editLayout.rows[selectedRowForOps + 1]
                    editLayout.rows[selectedRowForOps + 1] = tmp
                    selectedRowForOps += 1
                    renderRowPicker()
                    renderPreview()
                    persist()
                }
            }
        })
        root.addView(rowMoveBar)

        val rowOpsBar1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val addKeyBtn = Button(this).apply {
            text = "+ 키"
            setOnClickListener { showAddKeyDialog(selectedRowForOps) }
        }
        val addDiacriticBtn = Button(this).apply {
            text = "+ 조합키"
            setOnClickListener { showAddDiacriticKeyDialog(selectedRowForOps) }
        }
        val removeRowBtn = Button(this).apply {
            text = "이 행 삭제"
            setOnClickListener {
                if (editLayout.rows.size <= 1) {
                    Toast.makeText(this@SettingsActivity, "최소 1개 행은 있어야 해요", Toast.LENGTH_SHORT).show()
                } else {
                    editLayout.rows.removeAt(selectedRowForOps)
                    selectedRowForOps = selectedRowForOps.coerceIn(0, editLayout.rows.size - 1)
                    renderRowPicker()
                    renderPreview()
                    persist()
                }
            }
        }
        rowOpsBar1.addView(addKeyBtn)
        rowOpsBar1.addView(addDiacriticBtn)
        rowOpsBar1.addView(removeRowBtn)
        root.addView(rowOpsBar1)

        val addRowBtn = Button(this).apply {
            text = "+ 새 행 추가"
            setOnClickListener {
                editLayout.rows.add(mutableListOf())
                selectedRowForOps = editLayout.rows.size - 1
                renderRowPicker()
                renderPreview()
                persist()
            }
        }

        val buttonBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val saveBtn = Button(this).apply {
            text = "저장 확인"
            setOnClickListener {
                persist()
                Toast.makeText(this@SettingsActivity, "저장되었습니다", Toast.LENGTH_SHORT).show()
            }
        }
        val resetBtn = Button(this).apply {
            text = "기본값으로 재설정"
            setOnClickListener {
                LayoutStore.resetLayout(this@SettingsActivity, currentCode)
                editLayout = LayoutStore.loadLayout(this@SettingsActivity, currentCode)
                selectedRowForOps = 0
                moveSourceKey = null
                keyboardView.highlightedKey = null
                renderRowPicker()
                renderPreview()
            }
        }
        val exportBtn = Button(this).apply {
            text = "내보내기"
            setOnClickListener {
                pendingExportJson = LayoutStore.exportJson(editLayout)
                exportFileLauncher.launch("keyboard_$currentCode.json")
            }
        }
        val importBtn = Button(this).apply {
            text = "가져오기"
            setOnClickListener {
                importFileLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
            }
        }
        buttonBar.addView(saveBtn)
        buttonBar.addView(resetBtn)
        buttonBar.addView(exportBtn)
        buttonBar.addView(importBtn)

        root.addView(addRowBtn)
        root.addView(buttonBar)

        setContentView(ScrollView(this).apply { addView(root) })
        renderLangTabs()
        renderRowPicker()
        renderPreview()
        updateDeletePageButtonVisibility()
    }

    /** 미리보기에서 키를 탭했을 때: 이동 모드면 취소만 처리(실제 이동은 onKeyTapDetail에서), 아니면 편집 다이얼로그. */
    private fun onPreviewKeyTapped(key: KeyDef) {
        val source = moveSourceKey
        if (source != null) {
            if (source === key) {
                moveSourceKey = null
                keyboardView.highlightedKey = null
            }
            return
        }
        val pos = findKeyPosition(key) ?: return
        if (key.type == KeyType.DIACRITIC) {
            showEditDiacriticKeyDialog(pos.first, pos.second)
        } else {
            showEditKeyDialog(pos.first, pos.second)
        }
    }

    private fun findKeyPosition(key: KeyDef): Pair<Int, Int>? {
        editLayout.rows.forEachIndexed { r, row ->
            row.forEachIndexed { k, kd ->
                if (kd === key) return r to k
            }
        }
        return null
    }

    /** source를 target의 왼쪽(insertBefore=true) 또는 오른쪽에 정확히 끼워넣습니다. */
    private fun performMoveWithSide(source: KeyDef, target: KeyDef, insertBefore: Boolean) {
        val srcPos = findKeyPosition(source) ?: return
        editLayout.rows[srcPos.first].removeAt(srcPos.second)
        val tgtPos = findKeyPosition(target) ?: return
        val targetRow = editLayout.rows[tgtPos.first]
        val targetIdx = targetRow.indexOfFirst { it === target }.let { if (it == -1) tgtPos.second else it }
        val insertIndex = if (insertBefore) targetIdx else targetIdx + 1
        targetRow.add(insertIndex.coerceIn(0, targetRow.size), source)
        renderPreview()
        persist()
    }

    /** 지금 편집 중인 레이아웃을 즉시 저장합니다. 수정할 때마다 자동으로 불러서 아무것도 안 사라져요. */
    private fun persist() {
        LayoutStore.saveLayout(this, currentCode, editLayout)
    }

    private fun renderPreview() {
        keyboardView.setLayout(editLayout)
    }

    private fun renderRowPicker() {
        rowPickerContainer.removeAllViews()
        editLayout.rows.forEachIndexed { idx, _ ->
            val btn = Button(this).apply {
                text = if (idx == selectedRowForOps) "▶ ${idx + 1}행" else "${idx + 1}행"
                setOnClickListener {
                    selectedRowForOps = idx
                    renderRowPicker()
                }
            }
            rowPickerContainer.addView(btn)
        }
    }

    private fun renderLangTabs() {
        langTabsContainer.removeAllViews()
        val installed = LanguageStore.installedLanguages(this)
        installed.forEach { lang ->
            val btn = Button(this).apply {
                text = if (lang.code == currentCode) "▶ ${lang.displayName}" else lang.displayName
                setOnClickListener { switchTab(lang.code) }
            }
            langTabsContainer.addView(btn)
        }
        val symbolPages = SymbolPageStore.getPages(this)
        symbolPages.forEachIndexed { i, code ->
            val label = "🔣${i + 1}"
            val btn = Button(this).apply {
                text = if (code == currentCode) "▶ $label" else label
                setOnClickListener { switchTab(code) }
            }
            langTabsContainer.addView(btn)
        }
        langTabsContainer.addView(Button(this).apply {
            text = "+ 기호 페이지"
            setOnClickListener {
                val newCode = SymbolPageStore.addPage(this@SettingsActivity)
                currentCode = newCode
                editLayout = LayoutStore.loadLayout(this@SettingsActivity, currentCode)
                selectedRowForOps = 0
                moveSourceKey = null
                keyboardView.highlightedKey = null
                renderLangTabs()
                renderRowPicker()
                renderPreview()
                updateDeletePageButtonVisibility()
            }
        })
        LayoutStore.emojiCategories.forEach { (code, label) ->
            langTabsContainer.addView(Button(this).apply {
                text = if (code == currentCode) "▶ $label" else label
                setOnClickListener { switchTab(code) }
            })
        }
        EmojiPageStore.getCustomPages(this).forEach { (code, label) ->
            langTabsContainer.addView(Button(this).apply {
                text = if (code == currentCode) "▶ 😀 $label" else "😀 $label"
                setOnClickListener { switchTab(code) }
            })
        }
        langTabsContainer.addView(Button(this).apply {
            text = "+ 이모지 페이지"
            setOnClickListener { showAddEmojiPageDialog() }
        })
    }

    private fun showAddEmojiPageDialog() {
        val input = EditText(this).apply { hint = "이 이모지 페이지의 이름 (예: 즐겨찾기)" }
        AlertDialog.Builder(this)
            .setTitle("새 이모지 페이지")
            .setView(input)
            .setPositiveButton("추가") { _, _ ->
                val name = input.text.toString()
                if (name.isNotEmpty()) {
                    val (newCode, _) = EmojiPageStore.addPage(this, name)
                    switchTab(newCode)
                }
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun switchTab(code: String) {
        currentCode = code
        editLayout = LayoutStore.loadLayout(this, currentCode)
        selectedRowForOps = 0
        moveSourceKey = null
        keyboardView.highlightedKey = null
        renderLangTabs()
        renderRowPicker()
        renderPreview()
        updateDeletePageButtonVisibility()
    }

    private fun updateDeletePageButtonVisibility() {
        deletePageBtn.visibility =
            if ((currentCode.startsWith("symbols") && currentCode != "symbols") ||
                currentCode.startsWith("emoji_custom_")
            ) {
                android.view.View.VISIBLE
            } else {
                android.view.View.GONE
            }
    }

    private data class KeyEditFields(
        val view: LinearLayout,
        val labelInput: EditText,
        val popupInput: EditText,
        val weightInput: EditText,
        val heightInput: EditText
    )

    /** 키 이름 입력칸 + 롱프레스 글자 입력칸 + 너비/높이 입력칸을 담은 다이얼로그용 뷰를 만듭니다. */
    private fun buildKeyEditView(
        labelText: String,
        popupText: String,
        weightText: String,
        heightText: String
    ): KeyEditFields {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 16, 48, 16)
        }
        val labelHint = TextView(this).apply { text = "키에 표시할 글자" }
        val labelInput = EditText(this).apply { setText(labelText) }
        val popupHint = TextView(this).apply {
            text = "길게 눌렀을 때 나오는 글자들 (쉼표로 구분, 예: á,à,â) - 안 써도 돼요"
            setPadding(0, 24, 0, 0)
        }
        val popupInput = EditText(this).apply { setText(popupText) }
        val weightHint = TextView(this).apply {
            text = "이 키의 너비 - 가로 (기본값 1.0, 크게 2.0, 작게 0.5)"
            setPadding(0, 24, 0, 0)
        }
        val weightInput = EditText(this).apply {
            setText(weightText)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        val heightHint = TextView(this).apply {
            text = "이 키의 높이 - 세로 (기본값 1.0, 다른 키들은 그대로 있고 이 키만 커지거나 작아져요)"
            setPadding(0, 24, 0, 0)
        }
        val heightInput = EditText(this).apply {
            setText(heightText)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        container.addView(labelHint)
        container.addView(labelInput)
        container.addView(popupHint)
        container.addView(popupInput)
        container.addView(weightHint)
        container.addView(weightInput)
        container.addView(heightHint)
        container.addView(heightInput)
        return KeyEditFields(container, labelInput, popupInput, weightInput, heightInput)
    }

    private fun parseWeight(text: String, fallback: Float): Float =
        text.trim().toFloatOrNull()?.takeIf { it > 0f } ?: fallback

    private fun parsePopup(text: String): List<String> =
        text.split(",").map { it.trim() }.filter { it.isNotEmpty() }

    private fun showAddKeyDialog(rowIndex: Int) {
        val fields = buildKeyEditView("", "", "1.0", "1.0")
        AlertDialog.Builder(this)
            .setTitle("키 추가")
            .setView(fields.view)
            .setPositiveButton("추가") { _, _ ->
                val label = fields.labelInput.text.toString()
                if (label.isNotEmpty()) {
                    val newKey = KeyDef(
                        label,
                        KeyType.NORMAL,
                        weight = parseWeight(fields.weightInput.text.toString(), 1f),
                        popup = parsePopup(fields.popupInput.text.toString()),
                        heightScale = parseWeight(fields.heightInput.text.toString(), 1f)
                    )
                    editLayout.rows[rowIndex].add(newKey)
                    renderPreview()
                    persist()
                    startPlacingNewKey(newKey)
                }
            }
            .setNegativeButton("취소", null)
            .show()
    }

    /** 새로 추가한 키를 강조 표시하고 이동 모드로 전환해서, 바로 원하는 자리를 탭해 위치를 정할 수 있게 합니다. */
    private fun startPlacingNewKey(key: KeyDef) {
        moveSourceKey = key
        keyboardView.highlightedKey = key
        Toast.makeText(
            this,
            "새 키가 파란색으로 표시됐어요. 원하는 자리의 키를 탭해서 위치를 정해주세요 (지금 자리가 좋으면 같은 키를 다시 탭)",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun showEditKeyDialog(rowIndex: Int, keyIndex: Int) {
        val key = editLayout.rows[rowIndex][keyIndex]
        val fields = buildKeyEditView(
            key.label,
            key.popup.joinToString(","),
            key.weight.toString(),
            key.heightScale.toString()
        )

        val copyBtn = Button(this).apply { text = "다른 언어로 복사" }
        val moveBtn = Button(this).apply { text = "다른 언어로 이동" }
        fields.view.addView(copyBtn)
        fields.view.addView(moveBtn)

        val dialog = AlertDialog.Builder(this)
            .setTitle("키 편집")
            .setView(fields.view)
            .setPositiveButton("변경") { _, _ ->
                val newLabel = fields.labelInput.text.toString()
                if (newLabel.isNotEmpty()) {
                    key.label = newLabel
                    key.popup = parsePopup(fields.popupInput.text.toString())
                    key.weight = parseWeight(fields.weightInput.text.toString(), key.weight)
                    key.heightScale = parseWeight(fields.heightInput.text.toString(), key.heightScale)
                    renderPreview()
                    persist()
                }
            }
            .setNeutralButton("삭제") { _, _ ->
                editLayout.rows[rowIndex].removeAt(keyIndex)
                renderPreview()
                persist()
            }
            .setNegativeButton("취소", null)
            .create()

        copyBtn.setOnClickListener {
            dialog.dismiss()
            showLanguageTargetPicker(key, rowIndex, keyIndex, isMove = false)
        }
        moveBtn.setOnClickListener {
            dialog.dismiss()
            showLanguageTargetPicker(key, rowIndex, keyIndex, isMove = true)
        }

        dialog.show()
    }

    /** 이 키를 다른 언어(또는 특수문자) 탭으로 복사하거나 이동합니다. 대상 언어의 마지막 줄 끝에 추가돼요. */
    private fun showLanguageTargetPicker(key: KeyDef, rowIndex: Int, keyIndex: Int, isMove: Boolean) {
        val targets = (LanguageStore.installedLanguages(this).map { it.code to it.displayName } +
            ("symbols" to "🔣 특수문자")).filter { it.first != currentCode }
        if (targets.isEmpty()) {
            Toast.makeText(this, "복사/이동할 다른 언어가 없어요. 먼저 언어를 켜주세요.", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = targets.map { it.second }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(if (isMove) "어느 언어로 이동할까요?" else "어느 언어로 복사할까요?")
            .setItems(labels) { _, which ->
                val targetCode = targets[which].first
                val targetLayout = LayoutStore.loadLayout(this, targetCode)
                if (targetLayout.rows.isEmpty()) targetLayout.rows.add(mutableListOf())
                targetLayout.rows.last().add(key.copy())
                LayoutStore.saveLayout(this, targetCode, targetLayout)

                if (isMove) {
                    editLayout.rows[rowIndex].removeAt(keyIndex)
                    renderPreview()
                    persist()
                }
                Toast.makeText(
                    this,
                    "${targets[which].second} 탭 마지막 줄에 ${if (isMove) "이동" else "복사"}됐어요",
                    Toast.LENGTH_SHORT
                ).show()
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private data class DiacriticEditFields(
        val view: ScrollView,
        val labelInput: EditText,
        val weightInput: EditText,
        val heightInput: EditText,
        val getMark: () -> String?
    )

    /** 프리셋 목록을 보여주고 고른 기호를 콜백으로 돌려주는 조합 키 다이얼로그 뷰를 만듭니다. */
    private fun buildDiacriticEditView(
        labelText: String,
        preselectedMark: String?,
        weightText: String,
        heightText: String
    ): DiacriticEditFields {
        var selectedMark: String? = preselectedMark
        var customInputRef: EditText? = null
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 16, 48, 16)
        }
        val labelHint = TextView(this).apply { text = "키에 표시할 글자 (예: SẮC)" }
        val labelInput = EditText(this).apply { setText(labelText) }
        container.addView(labelHint)
        container.addView(labelInput)

        val presetHint = TextView(this).apply {
            text = "합쳐질 기호를 선택하세요 (앞 글자에 붙어요)"
            setPadding(0, 24, 0, 8)
        }
        container.addView(presetHint)

        val presetButtons = mutableListOf<Pair<Button, String>>()
        markPresets.forEach { (labelText2, mark) ->
            val btn = Button(this).apply {
                text = if (mark == preselectedMark) "✓ $labelText2" else labelText2
                setOnClickListener {
                    selectedMark = mark
                    customInputRef?.setText("")
                    presetButtons.forEach { (b, m) -> b.text = markPresets.first { it.second == m }.first }
                    text = "✓ $labelText2"
                }
            }
            presetButtons.add(btn to mark)
            container.addView(btn)
        }

        val customHint = TextView(this).apply {
            text = "또는 직접 유니코드 문자를 붙여넣으세요 (프리셋에 없는 기호도 가능)"
            setPadding(0, 24, 0, 8)
        }
        container.addView(customHint)
        val customInput = EditText(this).apply {
            hint = "여기에 붙여넣기"
            if (preselectedMark != null && markPresets.none { it.second == preselectedMark } && preselectedMark != "STROKE") {
                setText(preselectedMark)
            }
        }
        customInputRef = customInput
        container.addView(customInput)

        val weightHint = TextView(this).apply {
            text = "이 키의 너비 - 가로 (기본값 1.0)"
            setPadding(0, 24, 0, 0)
        }
        container.addView(weightHint)
        val weightInput = EditText(this).apply {
            setText(weightText)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        container.addView(weightInput)

        val heightHint = TextView(this).apply {
            text = "이 키의 높이 - 세로 (기본값 1.0, 다른 키는 그대로 있어요)"
            setPadding(0, 24, 0, 0)
        }
        container.addView(heightHint)
        val heightInput = EditText(this).apply {
            setText(heightText)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        container.addView(heightInput)

        val scroll = ScrollView(this).apply { addView(container) }
        return DiacriticEditFields(scroll, labelInput, weightInput, heightInput) {
            val custom = customInput.text.toString()
            if (custom.isNotEmpty()) custom else selectedMark
        }
    }

    private fun showAddDiacriticKeyDialog(rowIndex: Int) {
        val fields = buildDiacriticEditView("", null, "1.0", "1.0")
        AlertDialog.Builder(this)
            .setTitle("조합 키 추가 (예: 성조, 발음기호)")
            .setView(fields.view)
            .setPositiveButton("추가") { _, _ ->
                val label = fields.labelInput.text.toString()
                val mark = fields.getMark()
                if (label.isNotEmpty() && mark != null) {
                    val newKey = KeyDef(
                        label,
                        KeyType.DIACRITIC,
                        weight = parseWeight(fields.weightInput.text.toString(), 1f),
                        mark = mark,
                        heightScale = parseWeight(fields.heightInput.text.toString(), 1f)
                    )
                    editLayout.rows[rowIndex].add(newKey)
                    renderPreview()
                    persist()
                    startPlacingNewKey(newKey)
                } else {
                    Toast.makeText(this, "이름과 기호를 모두 정해주세요", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun showEditDiacriticKeyDialog(rowIndex: Int, keyIndex: Int) {
        val key = editLayout.rows[rowIndex][keyIndex]
        val fields = buildDiacriticEditView(key.label, key.mark, key.weight.toString(), key.heightScale.toString())

        val copyBtn = Button(this).apply { text = "다른 언어로 복사" }
        val moveBtn = Button(this).apply { text = "다른 언어로 이동" }
        (fields.view.getChildAt(0) as LinearLayout).addView(copyBtn)
        (fields.view.getChildAt(0) as LinearLayout).addView(moveBtn)

        val dialog = AlertDialog.Builder(this)
            .setTitle("조합 키 편집")
            .setView(fields.view)
            .setPositiveButton("변경") { _, _ ->
                val newLabel = fields.labelInput.text.toString()
                val mark = fields.getMark()
                if (newLabel.isNotEmpty() && mark != null) {
                    key.label = newLabel
                    key.mark = mark
                    key.weight = parseWeight(fields.weightInput.text.toString(), key.weight)
                    key.heightScale = parseWeight(fields.heightInput.text.toString(), key.heightScale)
                    renderPreview()
                    persist()
                }
            }
            .setNeutralButton("삭제") { _, _ ->
                editLayout.rows[rowIndex].removeAt(keyIndex)
                renderPreview()
                persist()
            }
            .setNegativeButton("취소", null)
            .create()

        copyBtn.setOnClickListener {
            dialog.dismiss()
            showLanguageTargetPicker(key, rowIndex, keyIndex, isMove = false)
        }
        moveBtn.setOnClickListener {
            dialog.dismiss()
            showLanguageTargetPicker(key, rowIndex, keyIndex, isMove = true)
        }

        dialog.show()
    }

    companion object {
        const val EXTRA_LANG_CODE = "lang_code"
    }
}
