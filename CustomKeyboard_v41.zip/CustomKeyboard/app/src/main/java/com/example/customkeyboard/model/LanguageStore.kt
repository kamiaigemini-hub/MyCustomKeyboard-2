package com.example.customkeyboard.model

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * 어떤 언어가 "설치"(켜짐) 되어 있는지 관리하고,
 * 사용자가 직접 새 언어를 추가/삭제할 수 있게 해줍니다.
 */
object LanguageStore {

    private const val PREFS = "keyboard_prefs"
    private const val KEY_INSTALLED = "installed_languages"
    private const val KEY_CUSTOM = "custom_languages"

    // 앱에 기본으로 들어있는 언어 (한국어는 자모 조합 엔진 사용)
    val ALL: List<LanguageDef> = listOf(
        LanguageDef("ko", "한국어", isHangul = true),
        LanguageDef("ko_cheonjiin", "한국어 (천지인)", isHangul = true, isCheonjiin = true),
        LanguageDef("en", "English"),
        LanguageDef("vi", "Tiếng Việt (베트남어)", isViTone = true),
        LanguageDef("zalgo", "Zalgo")
    )

    fun customLanguages(context: Context): List<LanguageDef> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_CUSTOM, null) ?: return emptyList()
        val arr = JSONArray(json)
        val list = mutableListOf<LanguageDef>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(LanguageDef(o.getString("code"), o.getString("name")))
        }
        return list
    }

    /** 기본 언어 + 사용자가 추가한 언어를 모두 합친 전체 목록 */
    fun allLanguages(context: Context): List<LanguageDef> = ALL + customLanguages(context)

    /** 새 언어를 추가합니다. 영어 자판을 복사한 빈 틀로 시작해서, 바로 편집할 수 있어요. */
    fun addCustomLanguage(context: Context, displayName: String): LanguageDef {
        val code = "custom_${System.currentTimeMillis()}"
        val newLang = LanguageDef(code, displayName)
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray()
        (customLanguages(context) + newLang).forEach {
            val o = JSONObject()
            o.put("code", it.code)
            o.put("name", it.displayName)
            arr.put(o)
        }
        prefs.edit().putString(KEY_CUSTOM, arr.toString()).apply()
        setInstalled(context, code, true)
        return newLang
    }

    /** 사용자가 만든 언어를 완전히 삭제합니다 (기본 언어는 삭제 불가, 켜고 끄기만 가능). */
    fun removeCustomLanguage(context: Context, code: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val remaining = customLanguages(context).filter { it.code != code }
        val arr = JSONArray()
        remaining.forEach {
            val o = JSONObject()
            o.put("code", it.code)
            o.put("name", it.displayName)
            arr.put(o)
        }
        prefs.edit().putString(KEY_CUSTOM, arr.toString()).apply()
        setInstalled(context, code, false)
        LayoutStore.resetLayout(context, code)
    }

    fun installedCodes(context: Context): Set<String> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getStringSet(KEY_INSTALLED, null) ?: setOf("ko", "en")
    }

    fun setInstalled(context: Context, code: String, installed: Boolean) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = installedCodes(context).toMutableSet()
        if (installed) current.add(code) else current.remove(code)
        if (current.isEmpty()) current.add("en") // 최소 1개는 항상 남겨둠
        prefs.edit().putStringSet(KEY_INSTALLED, current).apply()
    }

    fun installedLanguages(context: Context): List<LanguageDef> {
        val codes = installedCodes(context)
        return allLanguages(context).filter { it.code in codes }
    }

    fun defByCode(context: Context, code: String): LanguageDef =
        allLanguages(context).firstOrNull { it.code == code } ?: ALL[1]
}
