package com.example.customkeyboard.text

import android.view.inputmethod.InputConnection
import java.text.Normalizer

/**
 * "글자를 치고 나서 조합 키를 누르면 방금 친 글자에 합쳐지는" 방식의 범용 엔진.
 * 베트남어뿐 아니라 어떤 언어든, DIACRITIC 타입 키가 있으면 똑같이 작동합니다.
 * 실제 합치는 계산은 안드로이드에 내장된 유니코드 정규화(Normalizer)에 맡깁니다.
 */
class DiacriticComposer(private val getIC: () -> InputConnection?) {

    companion object {
        private val TONE_LIKE_MARKS = setOf("\u0301", "\u0300", "\u0309", "\u0303", "\u0323")
    }

    private var baseChar: Char? = null
    private var shapeMark: String? = null
    private var toneMark: String? = null
    private var isStroke = false

    /** 방금 커밋된 글자가 한 글자면 호출해서 "이어붙일 대상"으로 기억합니다. */
    fun onBaseLetterTyped(ch: Char) {
        baseChar = ch
        shapeMark = null
        toneMark = null
        isStroke = false
    }

    fun reset() {
        baseChar = null
        shapeMark = null
        toneMark = null
        isStroke = false
    }

    /** 조합 키를 눌렀을 때 호출. 합칠 대상이 없거나 조합이 안 되면 아무 일도 하지 않습니다. */
    fun applyDiacritic(mark: String) {
        val ic = getIC() ?: return
        val base = baseChar ?: return
        if (isStroke) return // 이미 특수 치환된 글자 뒤에는 추가로 합치지 않음 (간단화)

        if (mark == "STROKE") {
            // d -> đ 같은, 결합이 아니라 통째로 바뀌는 특수 케이스
            if (base != 'd' && base != 'D') return
            val result = if (base == 'D') "Đ" else "đ"
            ic.deleteSurroundingText(1, 0)
            ic.commitText(result, 1)
            isStroke = true
            return
        }

        if (mark in TONE_LIKE_MARKS) toneMark = mark else shapeMark = mark

        val combined = base.toString() + (shapeMark ?: "") + (toneMark ?: "")
        val composed = Normalizer.normalize(combined, Normalizer.Form.NFC)
        if (composed.length != 1) return // 이 글자와는 조합이 안 되면 그냥 무시

        ic.deleteSurroundingText(1, 0)
        ic.commitText(composed, 1)
    }
}
