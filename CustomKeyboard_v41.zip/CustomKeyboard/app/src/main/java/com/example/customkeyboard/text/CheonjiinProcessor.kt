package com.example.customkeyboard.text

import android.os.Handler
import android.os.Looper

/**
 * 천지인 입력 엔진.
 * - 모음: ㅣ, ㆍ, ㅡ 세 획을 순서대로 눌러서 합칩니다 (예: ㅣ+ㆍ = ㅏ)
 * - 자음: 같은 키를 짧은 시간 안에 여러 번 누르면 ㄱ→ㅋ→ㄲ 처럼 순환합니다
 * 실제 글자 합치기(초성+중성+종성)는 기존 HangulComposer를 그대로 재사용합니다.
 */
class CheonjiinProcessor(private val composer: HangulComposer) {

    companion object {
        private const val MULTITAP_TIMEOUT = 700L
        private const val STROKE_TIMEOUT = 350L

        private val VOWEL_MAP = mapOf(
            "ㅣㆍ" to 'ㅏ',
            "ㅣㆍㆍ" to 'ㅑ',
            "ㆍㅣ" to 'ㅓ',
            "ㆍㆍㅣ" to 'ㅕ',
            "ㅡㆍ" to 'ㅗ',
            "ㅡㆍㆍ" to 'ㅛ',
            "ㆍㅡ" to 'ㅜ',
            "ㆍㆍㅡ" to 'ㅠ',
            "ㅡ" to 'ㅡ',
            "ㅣ" to 'ㅣ',
            "ㅡㅣ" to 'ㅢ',
            "ㅣㆍㅣ" to 'ㅐ',
            "ㆍㅣㅣ" to 'ㅔ'
        )
    }

    private val handler = Handler(Looper.getMainLooper())

    // 자음 다중탭(같은 키 반복해서 ㄱ→ㅋ→ㄲ 순환) 상태
    private var lastConsGroup: List<Char>? = null
    private var consCycleIndex = 0
    private var lastConsTime = 0L

    // 모음 획 누적 상태
    private val strokeBuffer = StringBuilder()
    private val strokeFinalizeRunnable = Runnable { finalizeStrokeNow() }

    /** 자음 그룹 키를 눌렀을 때 호출 (예: [ㄱ, ㅋ, ㄲ]) */
    fun pressConsonant(group: List<Char>) {
        if (group.isEmpty()) return
        finalizeStrokeNow()
        val now = System.currentTimeMillis()
        if (lastConsGroup == group && now - lastConsTime < MULTITAP_TIMEOUT) {
            // 같은 키를 다시 눌렀으므로 방금 입력한 글자를 지우고 다음 글자로 순환
            composer.backspace()
            consCycleIndex = (consCycleIndex + 1) % group.size
        } else {
            consCycleIndex = 0
        }
        lastConsGroup = group
        lastConsTime = now
        composer.inputJamo(group[consCycleIndex])
    }

    /** ㅣ, ㆍ, ㅡ 획 키를 눌렀을 때 호출 */
    fun pressStroke(stroke: Char) {
        lastConsGroup = null
        handler.removeCallbacks(strokeFinalizeRunnable)
        val candidate = strokeBuffer.toString() + stroke
        val canContinue = VOWEL_MAP.keys.any { it == candidate || it.startsWith(candidate) }
        if (canContinue) {
            strokeBuffer.append(stroke)
        } else {
            finalizeStrokeNow()
            strokeBuffer.append(stroke)
        }
        handler.postDelayed(strokeFinalizeRunnable, STROKE_TIMEOUT)
    }

    private fun finalizeStrokeNow() {
        handler.removeCallbacks(strokeFinalizeRunnable)
        if (strokeBuffer.isEmpty()) return
        val vowel = VOWEL_MAP[strokeBuffer.toString()]
        if (vowel != null) composer.inputJamo(vowel)
        strokeBuffer.clear()
    }

    /** 스페이스/엔터/다른 키 등을 누르면 지금까지 조합 중인 걸 모두 확정합니다. */
    fun commitAll() {
        finalizeStrokeNow()
        lastConsGroup = null
        composer.commit()
    }

    /** 새 입력 세션이 시작될 때, 아무것도 보내지 않고 예전 조합 상태만 그냥 지웁니다. */
    fun reset() {
        handler.removeCallbacks(strokeFinalizeRunnable)
        strokeBuffer.clear()
        lastConsGroup = null
        composer.reset()
    }

    fun backspace(): Boolean {
        handler.removeCallbacks(strokeFinalizeRunnable)
        if (strokeBuffer.isNotEmpty()) {
            strokeBuffer.deleteCharAt(strokeBuffer.length - 1)
            return true
        }
        lastConsGroup = null
        return composer.backspace()
    }
}
