package com.example.customkeyboard.model

/**
 * 키보드가 지원하는 언어 하나를 표현.
 * isHangul이 true면 자음/모음 조합(한글 입력) 엔진을 사용합니다.
 */
data class LanguageDef(
    val code: String,
    val displayName: String,
    val isHangul: Boolean = false,
    val isCheonjiin: Boolean = false,
    val isViTone: Boolean = false
)
